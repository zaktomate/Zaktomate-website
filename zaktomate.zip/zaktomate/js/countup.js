/* ============================================
   ZAKTOMATE — Count-Up Animation
   Lightweight stat counter triggered by observer
   ============================================ */

class CountUp {
  constructor(element, options = {}) {
    this.element = element;
    this.target = element.getAttribute('data-target') || element.textContent;
    this.duration = options.duration || 2000;
    this.started = false;
    
    // Parse the target value
    this.parseTarget();
  }

  parseTarget() {
    const raw = this.target.trim();
    
    // Handle various formats
    if (raw.includes('%')) {
      this.suffix = '%';
      this.value = parseFloat(raw);
      this.decimals = raw.includes('.') ? raw.split('.')[1].replace('%', '').length : 0;
    } else if (raw.includes('x')) {
      this.suffix = 'x';
      this.value = parseFloat(raw);
      this.decimals = raw.includes('.') ? raw.split('.')[1].replace('x', '').length : 0;
    } else if (raw.includes('hrs')) {
      this.suffix = ' hrs';
      this.value = parseFloat(raw);
      this.decimals = raw.includes('.') ? raw.split('.')[1].replace(' hrs', '').replace('hrs', '').length : 0;
    } else if (raw.includes('min')) {
      // Handle "< 2min" type
      this.prefix = '< ';
      this.suffix = 'min';
      this.value = parseFloat(raw.replace('<', '').replace('min', ''));
      this.decimals = 0;
    } else if (raw.includes('–')) {
      // Handle ranges like "2x–3x"
      this.isRange = true;
      this.rangeText = raw;
      this.value = 3; // animate to 3
      this.decimals = 0;
      return;
    } else {
      this.suffix = '';
      this.value = parseFloat(raw);
      this.decimals = raw.includes('.') ? raw.split('.')[1].length : 0;
    }
  }

  start() {
    if (this.started) return;
    this.started = true;

    const startTime = performance.now();
    const startValue = 0;

    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / this.duration, 1);
      
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = startValue + (this.value - startValue) * eased;

      if (this.isRange) {
        const v1 = Math.round(current * (2/3));
        const v2 = Math.round(current);
        this.element.textContent = `${Math.max(1, v1)}x–${Math.max(1, v2)}x`;
      } else {
        let display = current.toFixed(this.decimals);
        this.element.textContent = (this.prefix || '') + display + (this.suffix || '');
      }

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }
}

// Initialize count-up elements
document.addEventListener('DOMContentLoaded', () => {
  const countElements = document.querySelectorAll('[data-countup]');
  
  const countObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const countup = new CountUp(entry.target);
        countup.start();
        countObserver.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.3
  });

  countElements.forEach(el => countObserver.observe(el));
});
