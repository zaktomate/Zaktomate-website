/* ============================================
   ZAKTOMATE — Form Validation & Submission
   Real-time validation, character counter, submit
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('audit-form');
  if (!form) return;

  const nameInput = form.querySelector('#full-name');
  const companyInput = form.querySelector('#company-name');
  const whatsappInput = form.querySelector('#whatsapp-number');
  const emailInput = form.querySelector('#email-address');
  const challengeInput = form.querySelector('#challenge');
  const charCounter = form.querySelector('#char-counter');
  const submitBtn = form.querySelector('#submit-btn');
  const formCard = document.querySelector('.form-card');
  const successCard = document.querySelector('.success-card');

  const WEBHOOK_URL = 'https://your-webhook-url.example.com/submit';

  // --- Validation Rules ---
  function validateName(val) { return val.trim().length >= 2; }
  function validateCompany(val) { return val.trim().length >= 2; }
  function validateWhatsApp(val) {
    const digits = val.replace(/\D/g, '');
    return digits.length >= 9 && digits.length <= 11;
  }
  function validateEmail(val) {
    if (!val.trim()) return true; // optional
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim());
  }

  // --- Visual Feedback ---
  function setFieldState(input, valid) {
    input.classList.remove('field-valid', 'field-invalid');
    if (input.value.trim() === '') return;
    input.classList.add(valid ? 'field-valid' : 'field-invalid');
  }

  // --- Check all required fields ---
  function checkFormValidity() {
    const nameOk = validateName(nameInput?.value || '');
    const companyOk = validateCompany(companyInput?.value || '');
    const whatsappOk = validateWhatsApp(whatsappInput?.value || '');
    
    if (submitBtn) {
      submitBtn.disabled = !(nameOk && companyOk && whatsappOk);
    }
  }

  // --- Real-time validation ---
  nameInput?.addEventListener('input', () => {
    setFieldState(nameInput, validateName(nameInput.value));
    checkFormValidity();
  });

  companyInput?.addEventListener('input', () => {
    setFieldState(companyInput, validateCompany(companyInput.value));
    checkFormValidity();
  });

  whatsappInput?.addEventListener('input', () => {
    // Only allow digits
    whatsappInput.value = whatsappInput.value.replace(/\D/g, '');
    setFieldState(whatsappInput, validateWhatsApp(whatsappInput.value));
    checkFormValidity();
  });

  emailInput?.addEventListener('input', () => {
    setFieldState(emailInput, validateEmail(emailInput.value));
  });

  // --- Character counter ---
  if (challengeInput && charCounter) {
    challengeInput.addEventListener('input', () => {
      const len = challengeInput.value.length;
      const max = 400;
      charCounter.textContent = `${len} / ${max}`;

      if (len > max) {
        challengeInput.value = challengeInput.value.substring(0, max);
        charCounter.textContent = `${max} / ${max}`;
      }

      charCounter.style.color = len > 350 ? 'var(--warning)' : 'var(--text-muted)';
    });
  }

  // --- Form Submit ---
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Final validation
    if (!validateName(nameInput.value) || 
        !validateCompany(companyInput.value) || 
        !validateWhatsApp(whatsappInput.value)) {
      return;
    }

    // Disable button
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="ph ph-spinner"></i> Submitting...';

    const formData = {
      name: nameInput.value.trim(),
      company: companyInput.value.trim(),
      whatsapp: '+880' + whatsappInput.value.trim(),
      email: emailInput?.value.trim() || '',
      challenge: challengeInput?.value.trim() || '',
      source: window.location.pathname,
      timestamp: new Date().toISOString()
    };

    try {
      // POST to webhook
      await fetch(WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
    } catch (err) {
      // Webhook might fail in dev — that's okay
      console.log('Form data:', formData);
    }

    // Show success state
    if (formCard) formCard.style.display = 'none';
    if (successCard) successCard.style.display = 'flex';
  });

  // Initial check
  checkFormValidity();
});
