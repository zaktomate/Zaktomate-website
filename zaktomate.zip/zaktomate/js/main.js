/* ============================================
   ZAKTOMATE — Main JavaScript
   Nav, scroll, observer, WA button, FAQ, hamburger
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  // --- Scroll Progress Bar ---
  const progressBar = document.getElementById('scroll-progress');
  
  function updateProgress() {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    if (progressBar) progressBar.style.width = progress + '%';
  }

  // --- Nav Scroll State ---
  const nav = document.querySelector('.nav');
  
  function updateNav() {
    if (nav) {
      if (window.scrollY > 60) {
        nav.classList.add('scrolled');
      } else {
        nav.classList.remove('scrolled');
      }
    }
  }

  // Combined scroll handler
  window.addEventListener('scroll', () => {
    updateProgress();
    updateNav();
  }, { passive: true });

  // --- Intersection Observer for Reveal Animations ---
  const revealElements = document.querySelectorAll('.reveal, .reveal-scale');
  
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -40px 0px'
  });

  revealElements.forEach(el => revealObserver.observe(el));

  // --- WhatsApp Float Button (appears after 3s) ---
  const waFloat = document.querySelector('.wa-float');
  if (waFloat) {
    setTimeout(() => {
      waFloat.classList.add('show');
    }, 3000);
  }

  // --- FAQ Accordion ---
  const faqItems = document.querySelectorAll('.faq-item');
  
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    if (question) {
      question.addEventListener('click', () => {
        const wasOpen = item.classList.contains('open');
        
        // Close all others
        faqItems.forEach(other => other.classList.remove('open'));
        
        // Toggle clicked
        if (!wasOpen) {
          item.classList.add('open');
        }
      });
    }
  });

  // --- Mobile Hamburger Menu ---
  const hamburger = document.querySelector('.nav-hamburger');
  const mobileOverlay = document.querySelector('.nav-mobile-overlay');
  const backdrop = document.querySelector('.nav-overlay-backdrop');
  const mobileLinks = document.querySelectorAll('.nav-mobile-overlay .nav-link');

  function openMobile() {
    hamburger?.classList.add('open');
    mobileOverlay?.classList.add('open');
    backdrop?.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeMobile() {
    hamburger?.classList.remove('open');
    mobileOverlay?.classList.remove('open');
    backdrop?.classList.remove('open');
    document.body.style.overflow = '';
  }

  hamburger?.addEventListener('click', () => {
    if (hamburger.classList.contains('open')) {
      closeMobile();
    } else {
      openMobile();
    }
  });

  backdrop?.addEventListener('click', closeMobile);

  mobileLinks.forEach(link => {
    link.addEventListener('click', closeMobile);
  });

  // --- Smooth Scroll for Anchor Links ---
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const targetId = link.getAttribute('href');
      if (targetId && targetId !== '#') {
        const target = document.querySelector(targetId);
        if (target) {
          e.preventDefault();
          const navHeight = nav ? nav.offsetHeight : 0;
          const targetPosition = target.getBoundingClientRect().top + window.scrollY - navHeight - 20;
          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
          });
        }
      }
    });
  });

  // --- Set active nav link based on current page ---
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      link.classList.add('active');
    }
  });
});
